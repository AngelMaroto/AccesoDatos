package jsl.com.farming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgricultoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgricultoresApplication.class, args);
	}

}
