package jsl.com.farming.repository;

import jsl.com.farming.entities.Granja;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GranjaRepository extends JpaRepository<Granja, Integer> {
}
