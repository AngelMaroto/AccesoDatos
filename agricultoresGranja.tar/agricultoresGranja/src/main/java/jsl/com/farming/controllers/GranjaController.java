package jsl.com.farming.controllers;
import jsl.com.farming.entities.Agricultor;
import jsl.com.farming.entities.Granja;
import jsl.com.farming.service.AgricultorServices;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/granja")
public class GranjaController {
}
